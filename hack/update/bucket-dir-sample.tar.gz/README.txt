This is a sample bucket data archive.

Expected directory structure:
.
├── README.txt
├── txt
│   ├── one.txt
│   ├── subdir
│   │   └── three.txt
│   └── two.txt
├── video
│   └── speedup.mkv
└── video-link.mkv -> video/speedup.mkv

